package hanaalalwi.ourproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class type extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

// this is when the user clicked on any butoon of these view the same page
        Button type = (Button) findViewById(R.id.devices);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i);

            }
        });

        Button type1 = (Button) findViewById(R.id.game);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i);

            }
        });

        Button type2 = (Button) findViewById(R.id.furniture);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i);

            }
        });

        Button type3 = (Button) findViewById(R.id.clothes);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i);

            }
        });

        Button type4 = (Button) findViewById(R.id.cobon);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i);

            }
        });

        Button type5 = (Button) findViewById(R.id.book);
        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(type.this, viewTypes.class);
                startActivity(i); }});


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
